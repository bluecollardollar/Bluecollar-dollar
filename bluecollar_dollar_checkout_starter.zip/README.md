# Bluecollar Dollar checkout starter

Files:
- `public/index.html` — storefront and cart, now calls a secure server endpoint
- `public/success.html`, `public/cancel.html` — checkout return pages
- `functions/api/create-checkout-session.js` — server-side Stripe Checkout Session creation

## Important
Product prices are demo values. Confirm supplier costs, inventory, product specifications, shipping, delivery estimates, returns, business details and tax obligations before taking orders. The function currently charges $0 standard shipping by default; set `SHIPPING_AMOUNT_CENTS` only after calculating the real shipping cost and margin. The 5–12 business-day estimate in the code is a placeholder: change it to verified supplier timing before launch. Do not rely on the success page as proof of payment.

## Stripe account and test mode
1. Create an account at https://dashboard.stripe.com/register using your real business/contact information.
2. Complete Stripe identity/business verification and payout bank setup.
3. In Stripe Dashboard, switch to Test mode and copy the test secret API key from Developers / API keys. Never put a secret key in HTML, a public repository, or chat.
4. Enable customer email receipts in Stripe settings before launch.

## Cloudflare Pages deployment
1. Create/sign in at https://dash.cloudflare.com/ and create a Pages project.
2. Put this package in a Git repository. Keep `functions/` at repository root. Set build command to none and build output directory to `public`.
3. In Pages > project > Settings > Variables and Secrets add:
   - `STRIPE_SECRET_KEY` — encrypted secret, test key first
   - `SITE_URL` — your exact deployed HTTPS URL, no trailing slash
   - `SHIPPING_AMOUNT_CENTS` — e.g. `0` or `499` for $4.99
4. Redeploy after adding secrets. Cloudflare Pages Functions route `/functions/api/create-checkout-session.js` to `/api/create-checkout-session`.

Cloudflare docs: https://developers.cloudflare.com/pages/functions/ and https://developers.cloudflare.com/pages/functions/bindings/

## Test
1. Keep Stripe in Test mode and deploy with the test secret key.
2. Add a product and click checkout.
3. Use Stripe's official test card `4242 4242 4242 4242`, any future expiry, any CVC and a valid ZIP.
4. Verify the payment in Stripe Dashboard. Test cancel, invalid cart, mobile view and US shipping address collection.
5. Do not enable live payments until supplier, pricing, policies, support email and fulfillment process are ready.

## Live mode
1. Complete Stripe account activation.
2. Replace the secret with the live secret key in the encrypted Cloudflare secret.
3. Set `SITE_URL` to the final domain and redeploy.
4. Run a carefully controlled real purchase/refund test before public marketing.
5. Configure Stripe email receipts and review tax requirements. This starter does not calculate or remit sales tax.

## Manual order fulfillment
For every order:
1. In Stripe Dashboard, verify payment status is **Succeeded**.
2. Record order/session, buyer email, products, quantities, shipping address, amount and date in a private order log.
3. Check supplier stock, total landed cost and current delivery estimate.
4. Place the supplier order manually using the buyer's shipping address.
5. Save supplier order number and tracking; send tracking to the buyer.
6. Monitor delivery, support requests, refunds and disputes.

This version does not automatically submit supplier orders, save orders in a database, send custom order emails, or process Stripe webhooks. The Stripe Dashboard is the payment source of truth. Do not ship based only on the browser success page. Add signed webhooks and a secure order database before order volume grows.

## Product price maintenance
The server-side allowlist in `functions/api/create-checkout-session.js` controls the charged prices. Update the product cards in `public/index.html` and this allowlist together. Amounts are cents: $24.99 = 2499.
